package edu.towson.cis.cosc603.project5.coffeemaker;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CoffeeMakerTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	private CoffeeMaker coffeemaker;
	private Recipe r;
	
	@Before
	public void setUp() throws Exception {
		coffeemaker = new CoffeeMaker();
		r = new Recipe();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCoffeeMaker() {
		assertNotNull(coffeemaker);
	}

	@Test
	public void testAddRecipe() {
		assertTrue(coffeemaker.addRecipe(r));
	}

	@Test
	public void testDeleteRecipe() {
		assertFalse(coffeemaker.deleteRecipe(r));
	}

	@Test
	public void testEditRecipe() {
		Recipe newRecipe = new Recipe();
		assertFalse(coffeemaker.editRecipe(r, newRecipe));
	}
/*
	@Test
	public void testAddInventory() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckInventory() {
		fail("Not yet implemented");
	}

	@Test
	public void testMakeCoffee() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRecipes() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRecipeForName() {
		fail("Not yet implemented");
	}
*/
}
