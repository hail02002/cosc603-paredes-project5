package edu.towson.cis.cosc603.project5.coffeemaker;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class RecipeTest {
	private Recipe r;

	@Before
	public void setUp() throws Exception {
		r = new Recipe();
	}

	@Test
	public void testGetAmtChocolateBadInput() {
		r.setAmtChocolate(-1);
		assertEquals(0, r.getAmtChocolate());
	}

	@Test
	public void testSetAmtChocolateBadInput() {
		r.setAmtChocolate(-1);
		assertEquals(0, r.getAmtChocolate());
	}

	@Test
	public void testGetAmtCoffeeBadInput() {
		r.setAmtCoffee(-1);
		assertEquals(0, r.getAmtCoffee());
	}

	@Test
	public void testSetAmtCoffeeBadInput() {
		r.setAmtCoffee(-1);
		assertEquals(0, r.getAmtCoffee());
	}

	@Test
	public void testGetAmtMilkBadInput() {
		r.setAmtMilk(-1);
		assertEquals(0, r.getAmtMilk());
	}

	@Test
	public void testSetAmtMilkBadInput() {
		r.setAmtMilk(-1);
		assertEquals(0, r.getAmtMilk());
	}

	@Test
	public void testGetAmtSugarBadInput() {
		r.setAmtSugar(-1);
		assertEquals(0, r.getAmtSugar());
	}

	@Test
	public void testSetAmtSugarBadInput() {
		r.setAmtSugar(-1);
		assertEquals(0, r.getAmtSugar());
	}

	@Test
	public void testGetPriceBadInput() {
		r.setAmtSugar(-1);
		assertEquals(0, r.getAmtSugar());
	}

	@Test
	public void testSetPrice() {
		fail("Not yet implemented");
	}

	@Test
	public void testEqualsRecipe() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
