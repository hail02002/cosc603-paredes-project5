package edu.towson.cis.cosc603.project5.coffeemaker;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class InventoryTest {
	private Inventory i;

	@Before
	public void setUp() throws Exception {
		i = new Inventory();
	}

	@Test
	public void testGetChocolate() {
		i.setChocolate(-1);
		assertEquals(0, i.getChocolate());
	}

	@Test
	public void testSetChocolateBadInput() {
		i.setChocolate(-1);
		assertEquals(0, 0);
	}

	@Test
	public void testGetCoffeeBadInput() {
		i.setCoffee(-1);
		assertEquals(0, i.getCoffee());
	}

	@Test
	public void testSetCoffeeBadInput() {
		i.setCoffee(-1);
		assertEquals(0, 0);
	}

	@Test
	public void testGetMilkBadInput() {
		i.setMilk(-1);
		assertEquals(0, i.getMilk());
	}

	@Test
	public void testSetMilkBadInput() {
		i.setMilk(-1);
		assertEquals(0, 0);
	}

	@Test
	public void testGetSugar() {
		i.setSugar(-1);
		assertEquals(0, i.getSugar());
	}

	@Test
	public void testSetSugar() {
		i.setSugar(-1);
		assertEquals(0, 0);
	}

	@Test
	public void testToStringBadInput() {
		i.setSugar(-1);
		i.setChocolate(-1);
		i.setMilk(-1);
		i.setCoffee(-1);
		int zero = 0;
		String expected = "Coffee: " + zero + "\n" +
				"Milk: " + zero + "\n" +
				"Sugar: " + zero + "\n" +
				"Chocolate: " + zero + "\n";
		String actual = "Coffee: " + i.getCoffee() + "\n" +
				"Milk: " + i.getMilk() + "\n" +
				"Sugar: " + i.getSugar() + "\n" +
				"Chocolate: " + i.getChocolate() + "\n";;
		assertEquals(0, 0);
	}
	
	@Test
	public void testIfEnoughIngredients() {
		i.setSugar(2);
		i.setChocolate(2);
		i.setMilk(2);
		i.setCoffee(2);
		Recipe r = new Recipe();
		assertTrue(i.enoughIngredients(r));
	}	

}
