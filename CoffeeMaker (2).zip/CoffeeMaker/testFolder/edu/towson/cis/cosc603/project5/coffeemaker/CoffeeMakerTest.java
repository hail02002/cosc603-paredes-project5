package edu.towson.cis.cosc603.project5.coffeemaker;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CoffeeMakerTest {

	private CoffeeMaker coffeemaker;
	private Recipe r;
	private Inventory inventory;
	
	@Before
	public void setUp() throws Exception {
		coffeemaker = new CoffeeMaker();
		r = new Recipe();
		inventory = new Inventory();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCoffeeMaker() {
		assertNotNull(coffeemaker);
	}

	@Test
	public void testCanAddRecipe() {
		assertTrue(coffeemaker.addRecipe(r));
	}
	
	@Test
	public void testCannotAddRecipe() {
		Recipe r1 = new Recipe();
		Recipe r2 = new Recipe();
		Recipe r3 = new Recipe();
		Recipe r4 = new Recipe();
		assertTrue(coffeemaker.addRecipe(r));
	}

	@Test
	public void testDeleteRecipe() {
		assertFalse(coffeemaker.deleteRecipe(r));
	}

	@Test
	public void testEditRecipe() {
		Recipe newRecipe = new Recipe();
		assertFalse(coffeemaker.editRecipe(r, newRecipe));
	}

	@Test
	public void testAddInventoryBadInput() {
		assertFalse(coffeemaker.addInventory(-1, -1, -1, -1));
	}
	
	@Test
	public void testAddInventoryGoodInput() {
		assertTrue(coffeemaker.addInventory(1, 1, 1, 1));
	}

/*
	@Test
	public void testCheckInventory() {
		fail("Not yet implemented");
	}

	@Test
	public void testMakeCoffee() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRecipes() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRecipeForName() {
		fail("Not yet implemented");
	}
*/
}
